const audiomenu = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *AUDIO #1* ❳
${tz} *${prefix}audio1*
${tz} *${prefix}audio2*
${tz} *${prefix}audio3*
${tz} *${prefix}audio4*
${tz} *${prefix}audio5*
${tz} *${prefix}audio6*
${tz} *${prefix}audio7*
${tz} *${prefix}audio8*
${tz} *${prefix}audio9*
${tz} *${prefix}audio10*
${tz} *${prefix}audio11*
${tz} *${prefix}audio12*
${tz} *${prefix}audio13*
${tz} *${prefix}audio14*
${tz} *${prefix}audio15*
${tz} *${prefix}audio16*
${tz} *${prefix}audio17*
${tz} *${prefix}audio18*
${tz} *${prefix}audio19*

❲ *AUDIO #2* ❳
${tz} *${prefix}audio20* 
${tz} *${prefix}audio21*
${tz} *${prefix}audio22*
${tz} *${prefix}audio23*
${tz} *${prefix}audio24*
${tz} *${prefix}audio25*
${tz} *${prefix}audio26*
${tz} *${prefix}audio27*
${tz} *${prefix}audio28*
${tz} *${prefix}audio29*
${tz} *${prefix}audio30*
${tz} *${prefix}audio31*
${tz} *${prefix}audio32*
${tz} *${prefix}audio33*
${tz} *${prefix}audio34*
${tz} *${prefix}audio35*

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.audiomenu = audiomenu