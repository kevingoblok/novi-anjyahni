const vcardrandom = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *VCARD RANDOM* ❳
${tz} *${prefix}vsadboy*
${tz} *${prefix}vpakboy*
${tz} *${prefix}vbaik*
${tz} *${prefix}vjago*
${tz} *${prefix}vjelek*
${tz} *${prefix}vcantik*
${tz} *${prefix}vpinter*
${tz} *${prefix}vbeban*
${tz} *${prefix}vkontol*
${tz} *${prefix}vhebat*
${tz} *${prefix}vwibu*
${tz} *${prefix}vharam*
${tz} *${prefix}vbabi*
${tz} *${prefix}vbego*
${tz} *${prefix}vganteng*
${tz} *${prefix}vanjing*
${tz} *${prefix}vmonyet*
${tz} *${prefix}vsadgirl*
${tz} *${prefix}vpakgirl*
${tz} *${prefix}vjahat*
${tz} *${prefix}vnolep*
${tz} *${prefix}vgoblok*

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.vcardrandom = vcardrandom