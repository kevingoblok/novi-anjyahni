const randomtext = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *RANDOM TEXT* ❳
${tz} *${prefix}brainly* <text>
${tz} *${prefix}brainly2* <reply.img>
${tz} *${prefix}toimg* <reply.img> 
${tz} *${prefix}tomp3* <reply.vid>
${tz} *${prefix}sticker* <reply.img>
${tz} *${prefix}shopee* <text>
${tz} *${prefix}youwatch* <text>
${tz} *${prefix}artinama* <text>
${tz} *${prefix}artimimpi* <text> 
${tz} *${prefix}attp* <text> 
${tz} *${prefix}foliokanan* <text> 
${tz} *${prefix}foliokiri* <text> 
${tz} *${prefix}nuliskanan* <text> 
${tz} *${prefix}nuliskiri* <text>  

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.randomtext = randomtext