const tagrandom = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *TAGRANDOM* ❳
${tz} *${prefix}sadboy*
${tz} *${prefix}pakboy*
${tz} *${prefix}baik*
${tz} *${prefix}jago*
${tz} *${prefix}jelek*
${tz} *${prefix}cantik*
${tz} *${prefix}pinter*
${tz} *${prefix}beban*
${tz} *${prefix}kontol*
${tz} *${prefix}hebat*
${tz} *${prefix}wibu*
${tz} *${prefix}haram*
${tz} *${prefix}babi*
${tz} *${prefix}bego*
${tz} *${prefix}ganteng*
${tz} *${prefix}anjing*
${tz} *${prefix}monyet*
${tz} *${prefix}sadgirl*
${tz} *${prefix}pakgirl*
${tz} *${prefix}jahat*
${tz} *${prefix}nolep*
${tz} *${prefix}goblok*

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.tagrandom = tagrandom