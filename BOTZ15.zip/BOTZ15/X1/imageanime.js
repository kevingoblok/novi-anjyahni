const imageanime = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *IMAGEANIME* ❳
${tz} *${prefix}saitama*
${tz} *${prefix}gon*
${tz} *${prefix}killua*
${tz} *${prefix}kakashi*
${tz} *${prefix}tsunade*
${tz} *${prefix}orochimaru*
${tz} *${prefix}mitsuki*
${tz} *${prefix}sarada*
${tz} *${prefix}boruto*
${tz} *${prefix}sakura*
${tz} *${prefix}sasuke*
${tz} *${prefix}minato*
${tz} *${prefix}naruto*
${tz} *${prefix}copper*
${tz} *${prefix}nami*
${tz} *${prefix}ussop*
${tz} *${prefix}sanji*
${tz} *${prefix}luffy*
${tz} *${prefix}zoro*
${tz} *${prefix}senku*
${tz} *${prefix}nezuko*
${tz} *${prefix}tanjirou*
${tz} *${prefix}natsu*
${tz} *${prefix}sagiri*
${tz} *${prefix}rimuru*

❲ *NSFW* ❳
${tz} *${prefix}neko-nsfw*
${tz} *${prefix}blowjob-nsfw*
${tz} *${prefix}kemonomimi-nsfw*
${tz} *${prefix}kitsune-nsfw*
${tz} *${prefix}yuri-nsfw*
${tz} *${prefix}boobs-nsfw*
${tz} *${prefix}kuni-nsfw*

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.imageanime = imageanime