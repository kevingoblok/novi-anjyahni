const textpro = (tz, nama, namabot, prefix, day, yy, thisDay, bulan, wib, wita, wit) => { 
	return `❲ *${namabot}* ❳
${tz} *OWNER* : ${nama}
${tz} *BOTNAME* : ${namabot}
${tz} *PREFIX* : *${prefix}* 
${tz} *TGGAL* : ${day}
${tz} *HARI KE* : ${yy}
${tz} *HARI* : ${thisDay}
${tz} *BULAN* : ${bulan}
${tz} *WIB* : ${wib}
${tz} *WITA* : ${wita}
${tz} *WIT* : ${wit}

❲ *TEXTPRO #1* ❳
${tz} *${prefix}glossy-blue* <text>
${tz} *${prefix}deluxe-gold* <text>
${tz} *${prefix}glossy-carbon* <text>
${tz} *${prefix}xmas* <text>
${tz} *${prefix}blood* <text>
${tz} *${prefix}halloween* <text>
${tz} *${prefix}matrix* <text>
${tz} *${prefix}christmas* <text>
${tz} *${prefix}winter* <text>
${tz} *${prefix}sky* <text>
${tz} *${prefix}luxury* <text>
${tz} *${prefix}gradient* <text>
${tz} *${prefix}vintage* <text>
${tz} *${prefix}beach* <text>
${tz} *${prefix}sand-writing* <text>
${tz} *${prefix}sand-engraved* <text>
${tz} *${prefix}glue-text* <text>
${tz} *${prefix}summery-sand* <text>

❲ *TEXTPRO #2* ❳
${tz} *${prefix}blackpink* <text>
${tz} *${prefix}joker* <text>
${tz} *${prefix}wicker* <text>
${tz} *${prefix}leaves* <text>
${tz} *${prefix}firework* <text>
${tz} *${prefix}lava* <text>
${tz} *${prefix}skeleton* <text>
${tz} *${prefix}toxic* <text>
${tz} *${prefix}thunder* <text>
${tz} *${prefix}horror* <text>
${tz} *${prefix}dropwater* <text>
${tz} *${prefix}break-wall* <text>
${tz} *${prefix}metal-dark* <text>
${tz} *${prefix}neon-light* <text>
${tz} *${prefix}minion-text* <text>
${tz} *${prefix}1917-style* <text>
${tz} *${prefix}holographic-3d* <text>
${tz} *${prefix}metal-purple* <text>
${tz} *${prefix}deluxe-silver* <text>

❲ *INFO LAIN* ❳
${tz} Jika bot tidak merespon, mungkin bot sedang off
${tz} bot tidak menyimpan riwayat foto/media
${tz} Silahkan beri waktu 5 detik penggunaan per fitur agar tidak menyebabkan spam
${tz} Jika menemukan bug/err silahkan hubungi owner
`
}
exports.textpro = textpro